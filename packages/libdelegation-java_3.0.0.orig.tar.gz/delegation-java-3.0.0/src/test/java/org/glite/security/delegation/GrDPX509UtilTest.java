package org.glite.security.delegation;

import junit.framework.TestCase;

public class GrDPX509UtilTest  extends TestCase {

}
