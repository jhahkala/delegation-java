delegation-java
===============

Library for implementing a java delegation service.